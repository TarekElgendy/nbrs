<?php

namespace App\Http\Livewire\Frontend\Profile;

use Livewire\Component;

class ListDataProfile extends Component
{
}
