<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\MajorCategory;
use App\Models\Page;
use App\Models\Product;
use App\Models\Productitem;
use App\Models\Section;
use Illuminate\Http\Request;
use PhpOffice\PhpSpreadsheet\Calculation\Web\Service;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;


class HomeController extends Controller
{
    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function account_blocked()
    {
        return view('frontend.user.inactiveAccount.index');
    } //end of function
    public function logout()
    {
        Session::flush();
        Auth::logout();
        return redirect()->route('home');
        // return redirect('login');

    } //end of logout
    public function index()
    {

        return view('frontend.home');
    } //end of method
    public function about()
    {
        $about = Page::where('type', 'aboutUs')->first();
        $message = Page::where('type', 'message')->first();
        $vision = Page::where('type', 'vision')->first();
        $mission = Page::where('type', 'mission')->first();
        $aboutVideo = Page::where('type', 'aboutVideo')->first();
        $testimonials = Page::where('type', 'testimonials')->get();
        return view('frontend.about', compact('about', 'message', 'vision', 'mission', 'aboutVideo', 'testimonials'));
    } //end of method
    public function howWeWork()
    {
        $howWeWork = Page::where('type', 'howWeWork')->get();
        return view('frontend.howWeWork', compact('howWeWork'));
    } //end of function
    public function blogs()
    {

        $blogs = Page::where('type', 'blogs')->get();
        return view('frontend.blogs', compact('blogs'));
    } //end of function
        public function blogDetails($id, $slug)
    {
        $blog = Page::where('type', 'blogs')->where('id', $id)->first();

        return view('frontend.blogDetails', compact('blog'));
    } //end of method
    public function jobs()
    {
        $jobs = Page::where('type', 'jobs')->first();
        return view('frontend.jobs', compact('jobs'));
    } //end of function
    public function Mediation_and_examination()
    {
        $mediation_and_examination = Page::where('type', 'Mediation_and_examination')->first();
        return view('frontend.mediation_and_examination', compact('mediation_and_examination'));
    } //end of function
    public function contactUs()
    {
        $services = Page::where('type', 'services')->get();
        return view('frontend.contact', compact('services'));
    } //end of method
    public function sections()
    {
        $sections = Section::where('status', 'active')->get();
        return view('frontend.sections', compact('sections'));
    } //end of method
    public function categories($id, $slug)
    {
        $section = Section::where('status', 'active')->where('id', $id)->first();
        $categories = Category::where('section_id', $id)->where('status', 'active')->get();
        return view('frontend.categories', compact('section', 'categories'));
    } //end of method
    public function products($id, $slug)
    {
        $category = Category::where('status', 'active')->where('id', $id)->first();
        $products = $category->products;
        return view('frontend.products', compact('category', 'products'));
    } //end of method
    public function productItems($id, $slug)
    {
        $product = Product::where('id', $id)->first();
        $techniques = Productitem::where('product_id', $id)->where('type', 'techniques')->where('status', 'active')->first();
        $techniquesItems = Productitem::where('product_id', $id)->where('type', 'techniquesItems')->where('status', 'active')->get();
        $advantages = Productitem::where('product_id', $id)->where('type', 'advantages')->where('status', 'active')->get();
        $materials = Productitem::where('product_id', $id)->where('type', 'materials')->where('status', 'active')->get();
        $finishes = Productitem::where('product_id', $id)->where('type', 'finishes')->where('status', 'active')->get();
        $gallery = Productitem::where('product_id', $id)->where('type', 'gallery')->where('status', 'active')->get();
        $comparisonTable = Productitem::where('product_id', $id)->where('type', 'comparisonTable')->where('status', 'active')->first();
        return view('frontend.productItems', compact(
            'product',
            'techniques',
            'techniquesItems',
            'advantages',
            'materials',
            'finishes',
            'gallery',
            'comparisonTable'
        ));
    } //end of method
        public function productItemsDetails($id, $slug)
    {
        $item = Productitem::where('id', $id)->where('type', 'techniquesItems')->where('status', 'active')->first();

        return view('frontend.productItemsDetails', compact('item'));

    } //end of method
    public function requestQuote($id, $slug)
    {
        $product = Product::find($id);

        $categories=$product->categories;
        $categoryIds = $categories->pluck('id');

        //FinishesAndPaint
        $finishesAndPaints = Page::where('type', 'FinishesAndPaint')->get();

        // $sameProducts = Product::whereHas('categories', function ($query) use ($categoryIds) {
        //     $query->whereIn('category_id', $categoryIds);
        // })->with('categories')->get();

        // $notSameProducts = Product::whereHas('categories', function ($query) use ($categoryIds) {
        //     $query->where('category_id', '<>',$categoryIds);
        // })->with('categories')->get();


        // $notSameProducts = Product::whereDoesntHave('categories', function ($query) use ($categoryIds) {
        //         $query->whereIn('category_id', $categoryIds)
        //           ->orWhereNull('category_id');
        // })->get();



      $productItems = Productitem::where('product_id', $product->id)->where('type','techniquesItems')->get();



    $majorCategories=MajorCategory::where('type','orderMaterials')->get();


        return view('frontend.requestQuote', compact('majorCategories','finishesAndPaints','product','productItems'  ));
    } //end of method

}
